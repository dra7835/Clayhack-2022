import time
import turtle
import array
from multiprocessing import Process





def ripple1(r: float, t: turtle) -> None:
    t.up()
    t.left(90)
    t.backward(r)
    t.right(90)
    t.down()
    t.circle(r)
    t.up()
    t.goto(0, 0)


def main():
    turtle.setup(1000, 1000)
    turtle.hideturtle()
    turtle.tracer(0, 0)
    turtles = []

    for i in range(7):
        t = turtle.Turtle()
        t.hideturtle()

        turtles.append(t)
    turtles[0].color('red')
    turtles[1].color('orange')
    turtles[2].color('yellow')
    turtles[3].color('green')
    turtles[4].color('blue')
    turtles[5].color('indigo')
    turtles[6].color('purple')
    for r in range(99999):
        for i in range(7):
            if r%700 >= 100 * i:
                ripple1((r % 700) - (100*i), turtles[i])
            elif r >= 100 * i:
                ripple1(r - (100 * i), turtles[i])

        turtle.update()
        time.sleep(.01)
        for t in turtles:
            t.clear()


if __name__ == '__main__':
    main()
